<img id="" class="h-12 w-auto text-white lg:h-16 lg:text-[#FF2D20]" src="https://codewing.co/wp-content/uploads/2021/03/codewing.png" />
